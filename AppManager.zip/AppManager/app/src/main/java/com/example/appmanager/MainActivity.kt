package com.example.appmanager

import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { _, grantResult ->
        UiState.granted = grantResult == PackageManager.PERMISSION_GRANTED
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(permissionListener)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                AppScreen()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        UiState.granted = ShizukuHelper.hasPermission()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppScreen() {
    val context = LocalContext.current
    val selected = UiState.selected

    LaunchedEffect(UiState.granted) {
        if (UiState.granted && UiState.apps.isEmpty()) {
            UiState.apps = withContext(Dispatchers.IO) { loadInstalledApps(context) }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(selected?.name ?: "App Manager") },
                navigationIcon = {
                    if (selected != null) {
                        IconButton(onClick = {
                            UiState.selected = null
                            UiState.output = ""
                        }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "กลับ")
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            when {
                !UiState.granted -> ShizukuGate()
                selected == null -> AppList()
                else -> AppDetail(selected)
            }
        }
    }
}

@Composable
fun ShizukuGate() {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (!ShizukuHelper.isServiceRunning()) {
            Text("ยังไม่ได้เปิด Shizuku", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Text(
                "เปิดแอป Shizuku แล้วเริ่มบริการก่อน (ผ่าน ADB หรือ Wireless debugging) จากนั้นกดปุ่มด้านล่าง",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(16.dp))
            Button(onClick = { UiState.granted = ShizukuHelper.hasPermission() }) {
                Text("ตรวจสอบอีกครั้ง")
            }
        } else {
            Text("ต้องการสิทธิ์จาก Shizuku", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(16.dp))
            Button(onClick = { ShizukuHelper.requestPermission() }) {
                Text("ขอสิทธิ์")
            }
        }
    }
}

@Composable
fun AppList() {
    LazyColumn(Modifier.fillMaxSize()) {
        items(UiState.apps, key = { it.packageName }) { app ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { UiState.selected = app }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                app.icon?.let {
                    Image(
                        bitmap = it,
                        contentDescription = null,
                        modifier = Modifier.size(44.dp)
                    )
                } ?: Spacer(Modifier.size(44.dp))
                Spacer(Modifier.width(16.dp))
                Column {
                    Text(app.name, style = MaterialTheme.typography.titleMedium)
                    Text(
                        app.packageName,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun AppDetail(app: AppItem) {
    val scope = rememberCoroutineScope()
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            app.icon?.let {
                Image(bitmap = it, contentDescription = null, modifier = Modifier.size(72.dp))
            }
            Spacer(Modifier.width(16.dp))
            Column {
                Text(app.name, style = MaterialTheme.typography.headlineSmall)
                Text(app.packageName, style = MaterialTheme.typography.bodyMedium)
            }
        }

        Spacer(Modifier.height(24.dp))

        Button(
            onClick = {
                scope.launch {
                    UiState.output = "กำลังทำงาน..."
                    // ตัวอย่างคำสั่ง: แสดงตำแหน่ง APK ของแอปที่เลือก
                    // เปลี่ยนคำสั่งตรงนี้ให้ตรงกับสิ่งที่ต้องการทำ
                    val cmd = "pm path ${app.packageName}"
                    UiState.output = withContext(Dispatchers.IO) { ShizukuHelper.exec(cmd) }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Use Root")
        }

        Spacer(Modifier.height(16.dp))

        if (UiState.output.isNotEmpty()) {
            Card(Modifier.fillMaxWidth()) {
                Text(
                    UiState.output,
                    modifier = Modifier.padding(12.dp),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

fun loadInstalledApps(context: android.content.Context): List<AppItem> {
    val pm = context.packageManager
    return pm.getInstalledApplications(PackageManager.GET_META_DATA)
        .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
        .map { info ->
            AppItem(
                name = pm.getApplicationLabel(info).toString(),
                packageName = info.packageName,
                icon = try {
                    pm.getApplicationIcon(info).toBitmap(96, 96).asImageBitmap()
                } catch (e: Exception) {
                    null
                }
            )
        }
        .sortedBy { it.name.lowercase() }
}
