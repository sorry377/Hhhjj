package com.example.appmanager

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap

data class AppItem(
    val name: String,
    val packageName: String,
    val icon: ImageBitmap?
)

object UiState {
    var granted by mutableStateOf(false)
    var apps by mutableStateOf<List<AppItem>>(emptyList())
    var selected by mutableStateOf<AppItem?>(null)
    var output by mutableStateOf("")
}
