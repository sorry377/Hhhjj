package com.example.appmanager

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuRemoteProcess

object ShizukuHelper {
    const val REQUEST_CODE = 1001

    fun isServiceRunning(): Boolean = Shizuku.pingBinder()

    fun hasPermission(): Boolean =
        try {
            isServiceRunning() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Exception) {
            false
        }

    fun requestPermission() {
        if (Shizuku.isPreV11()) return
        Shizuku.requestPermission(REQUEST_CODE)
    }

    /**
     * รันคำสั่ง shell ผ่าน Shizuku
     * newProcess เป็น private ใน Shizuku API ใหม่ จึงเรียกผ่าน reflection
     */
    fun exec(command: String): String {
        if (!hasPermission()) return "ยังไม่ได้รับสิทธิ์จาก Shizuku"
        return try {
            val method = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            method.isAccessible = true
            val process = method.invoke(
                null,
                arrayOf("sh", "-c", command),
                null,
                null
            ) as ShizukuRemoteProcess

            val out = process.inputStream.bufferedReader().readText()
            val err = process.errorStream.bufferedReader().readText()
            process.waitFor()
            (out + err).ifBlank { "(ไม่มีผลลัพธ์)" }
        } catch (e: Exception) {
            "เกิดข้อผิดพลาด: ${e.message}"
        }
    }
}
