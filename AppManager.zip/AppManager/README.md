# App Manager

Android app (Jetpack Compose) ที่ขอสิทธิ์ผ่าน Shizuku แล้วแสดงรายการแอปพร้อมไอคอน

## วิธีใช้
1. เปิด Shizuku (Wireless debugging หรือ ADB) แล้วเริ่มบริการ
2. เปิด App Manager กดขอสิทธิ์
3. เลือกแอปในรายการ แล้วกด Use Root

## Build
Push ขึ้น branch `main` แล้วดาวน์โหลด artifact `app-debug` จากแท็บ Actions
