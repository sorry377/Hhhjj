package com.nexra.worldboxmodloader.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.nexra.worldboxmodloader.R
import com.nexra.worldboxmodloader.detector.WorldBoxDetector
import com.nexra.worldboxmodloader.detector.WorldBoxPaths
import com.nexra.worldboxmodloader.extractor.GameFileExtractor
import com.nexra.worldboxmodloader.mod.ModManager
import com.nexra.worldboxmodloader.root.RootHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvRootStatus: TextView
    private lateinit var tvGameStatus: TextView
    private lateinit var tvLog: TextView
    private lateinit var btnDetect: Button
    private lateinit var btnExtract: Button
    private lateinit var btnImportLocal: Button
    private lateinit var btnSteamMod: Button
    private lateinit var btnApplyMods: Button

    private var gamePaths: WorldBoxPaths? = null
    private val scope = CoroutineScope(Dispatchers.Main)
    private val PICK_MOD = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        tvRootStatus = findViewById(R.id.tvRootStatus)
        tvGameStatus = findViewById(R.id.tvGameStatus)
        tvLog = findViewById(R.id.tvLog)
        btnDetect = findViewById(R.id.btnDetect)
        btnExtract = findViewById(R.id.btnExtract)
        btnImportLocal = findViewById(R.id.btnImportLocal)
        btnSteamMod = findViewById(R.id.btnSteamMod)
        btnApplyMods = findViewById(R.id.btnApplyMods)

        checkRoot()

        btnDetect.setOnClickListener { detectGame() }
        btnExtract.setOnClickListener { extractGame() }
        btnImportLocal.setOnClickListener { pickModFile() }
        btnSteamMod.setOnClickListener { pickModFile() }
        btnApplyMods.setOnClickListener { applyMods() }
    }

    private fun log(msg: String) {
        runOnUiThread {
            tvLog.append("$msg\n")
        }
    }

    private fun checkRoot() {
        scope.launch {
            val hasRoot = withContext(Dispatchers.IO) { RootHelper.isRootAvailable() }
            tvRootStatus.text = if (hasRoot) "Root: OK" else "Root: NOT FOUND (need Magisk/KernelSU)"
            if (!hasRoot) {
                log("Root required. Grant su permission.")
            } else {
                log("Root access granted.")
                ModManager.ensureDirs()
            }
        }
    }

    private fun detectGame() {
        scope.launch {
            tvStatus.text = "Status: Detecting..."
            val paths = withContext(Dispatchers.IO) { WorldBoxDetector.detect() }
            gamePaths = paths
            if (paths != null) {
                tvGameStatus.text = "WorldBox: Found\n${paths.dataDir}"
                tvStatus.text = "Status: Game detected"
                btnExtract.isEnabled = true
                btnImportLocal.isEnabled = true
                btnSteamMod.isEnabled = true
                btnApplyMods.isEnabled = true
                log("Detected WorldBox at ${paths.dataDir}")
                log("Files dir: ${paths.filesDir}")
            } else {
                tvGameStatus.text = "WorldBox: Not found"
                tvStatus.text = "Status: Not installed"
                log("WorldBox package com.mkarpenko.worldbox not found")
            }
        }
    }

    private fun extractGame() {
        val paths = gamePaths ?: return
        scope.launch {
            tvStatus.text = "Status: Extracting full files..."
            btnExtract.isEnabled = false
            withContext(Dispatchers.IO) {
                val out = ModManager.getWorkDirs()["extracted"]!!
                GameFileExtractor.extractFull(paths, out) { log(it) }
                val size = GameFileExtractor.getExtractSize(out)
                log("Extract size: $size")
            }
            tvStatus.text = "Status: Extract done"
            btnExtract.isEnabled = true
        }
    }

    private fun pickModFile() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(Intent.createChooser(intent, "Select Mod ZIP / File"), PICK_MOD)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_MOD && resultCode == Activity.RESULT_OK) {
            val uri = data?.data ?: return
            scope.launch {
                tvStatus.text = "Status: Importing mod..."
                withContext(Dispatchers.IO) {
                    // Copy content uri to temp then import
                    val tmp = "/data/local/tmp/worldbox_modloader/staging/import_${System.currentTimeMillis()}.zip"
                    try {
                        contentResolver.openInputStream(uri)?.use { input ->
                            // Write via root-accessible path
                            val localTmp = cacheDir.resolve("mod_import.zip")
                            localTmp.outputStream().use { output -> input.copyTo(output) }
                            RootHelper.runAsRoot("cp \"${localTmp.absolutePath}\" \"$tmp\"")
                            ModManager.importLocalMod(tmp) { log(it) }
                        }
                    } catch (e: Exception) {
                        log("Import error: ${e.message}")
                    }
                }
                tvStatus.text = "Status: Mod imported"
                log("Imported mods: ${ModManager.listImportedMods()}")
            }
        }
    }

    private fun applyMods() {
        val paths = gamePaths ?: return
        scope.launch {
            tvStatus.text = "Status: Applying mods..."
            btnApplyMods.isEnabled = false
            withContext(Dispatchers.IO) {
                ModManager.applyAllMods(paths) { log(it) }
            }
            tvStatus.text = "Status: Mods applied - restart game"
            btnApplyMods.isEnabled = true
        }
    }
}
