package com.nexra.worldboxmodloader.root

import java.io.BufferedReader
import java.io.DataOutputStream
import java.io.InputStreamReader

object RootHelper {

    fun isRootAvailable(): Boolean {
        return try {
            val process = Runtime.getRuntime().exec("su -c id")
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val result = reader.readText()
            process.waitFor()
            result.contains("uid=0")
        } catch (e: Exception) {
            false
        }
    }

    fun runAsRoot(command: String): String {
        return try {
            val process = Runtime.getRuntime().exec("su")
            val os = DataOutputStream(process.outputStream)
            os.writeBytes("$command\n")
            os.writeBytes("exit\n")
            os.flush()
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val errorReader = BufferedReader(InputStreamReader(process.errorStream))
            val output = reader.readText()
            val error = errorReader.readText()
            process.waitFor()
            if (error.isNotBlank()) "$output\n$error" else output
        } catch (e: Exception) {
            "ERROR: ${e.message}"
        }
    }

    fun copyWithRoot(src: String, dest: String): Boolean {
        val result = runAsRoot("cp -a \"$src\" \"$dest\" && echo OK")
        return result.contains("OK")
    }

    fun mkdirWithRoot(path: String): Boolean {
        val result = runAsRoot("mkdir -p \"$path\" && echo OK")
        return result.contains("OK")
    }

    fun listWithRoot(path: String): List<String> {
        val result = runAsRoot("ls -la \"$path\"")
        return result.lines().filter { it.isNotBlank() }
    }

    fun existsWithRoot(path: String): Boolean {
        val result = runAsRoot("test -e \"$path\" && echo EXISTS")
        return result.contains("EXISTS")
    }
}
