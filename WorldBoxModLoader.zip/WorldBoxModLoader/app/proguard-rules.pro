# Keep root related classes
-keep class com.nexra.worldboxmodloader.root.** { *; }
-keep class com.nexra.worldboxmodloader.extractor.** { *; }
-keep class com.nexra.worldboxmodloader.mod.** { *; }
