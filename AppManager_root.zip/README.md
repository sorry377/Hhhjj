# App Manager

Android app (Jetpack Compose) — รายการแอปพร้อมไอคอน, ค้นหา, Use Root, Terminal, ตั้งค่ารูปแบบการขอสิทธิ์

## รูปแบบการขอสิทธิ์ (ตั้งค่า)
- ADB + GKI: ADB (Shizuku) แล้วยกเป็น root จาก ADB shell ด้วย su (GKI root เช่น KernelSU/APatch)
- ROOT + ADB: su โดยตรงก่อน ถ้าไม่ได้ใช้ ADB
- ทุกวิธี: su โดยตรง → Shizuku root → ADB ยกเป็น root → ADB ปกติ

## Build
Push ขึ้น branch `main` แล้วดาวน์โหลด artifact `app-debug` จากแท็บ Actions
