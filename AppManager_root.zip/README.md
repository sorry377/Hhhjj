# App Manager

Android app (Jetpack Compose) — รายการแอปพร้อมไอคอน, ค้นหา, Use Root, Terminal

## โหมดสิทธิ์
- Root จริง (su): เครื่อง root ด้วย Magisk/KernelSU
- Root จริง (Shizuku): Shizuku เริ่มด้วย root
- Shizuku โหมด ADB: สิทธิ์ระดับ ADB (ไม่ใช่ root จริง)

## Build
Push ขึ้น branch `main` แล้วดาวน์โหลด artifact `app-debug` จากแท็บ Actions
