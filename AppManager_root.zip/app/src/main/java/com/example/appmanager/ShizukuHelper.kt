package com.example.appmanager

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuRemoteProcess

object ShizukuHelper {
    const val REQUEST_CODE = 1001

    fun isServiceRunning(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    fun hasPermission(): Boolean = try {
        isServiceRunning() &&
            !Shizuku.isPreV11() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    fun requestPermission() {
        try {
            if (!Shizuku.isPreV11()) Shizuku.requestPermission(REQUEST_CODE)
        } catch (e: Throwable) {
        }
    }

    /** 0 = Shizuku รันด้วย root, 2000 = รันด้วย ADB shell */
    fun uid(): Int = try {
        Shizuku.getUid()
    } catch (e: Throwable) {
        -1
    }

    /**
     * รันคำสั่ง shell ผ่าน Shizuku
     * newProcess เป็น private ใน Shizuku API ใหม่ จึงเรียกผ่าน reflection
     */
    fun exec(command: String): ExecResult {
        if (!hasPermission()) return ExecResult("ยังไม่ได้รับสิทธิ์จาก Shizuku", -1)
        return try {
            val method = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            method.isAccessible = true
            val process = method.invoke(
                null,
                arrayOf("sh", "-c", "($command) 2>&1"),
                null,
                null
            ) as ShizukuRemoteProcess
            RootManager.collect(process)
        } catch (e: Exception) {
            ExecResult("เกิดข้อผิดพลาด: ${e.cause?.message ?: e.message ?: e.javaClass.simpleName}", -1)
        }
    }
}
