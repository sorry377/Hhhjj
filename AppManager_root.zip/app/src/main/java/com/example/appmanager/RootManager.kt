package com.example.appmanager

import java.util.concurrent.atomic.AtomicBoolean

data class ExecResult(val output: String, val exitCode: Int)

object RootManager {

    // ตำแหน่ง su ที่พบบ่อย (Magisk / KernelSU / APatch / GKI root)
    private val suCandidates = listOf(
        "su",
        "/system/bin/su",
        "/system/xbin/su",
        "/sbin/su",
        "/debug_ramdisk/su",
        "/data/adb/ksu/bin/su",
        "/data/adb/ap/bin/su"
    )

    @Volatile
    private var suBinary: String? = null

    /**
     * หาช่องทางที่ใช้ได้ตามรูปแบบ (UiState.profile)
     * probe = true  → ลองขอ su จริง (อาจมีหน้าต่างขอสิทธิ์) ต้องเรียกใน background thread
     * probe = false → ตรวจเฉพาะสถานะเดิม + Shizuku (เบา)
     */
    fun refresh(probe: Boolean) {
        val running = ShizukuHelper.isServiceRunning()
        val perm = ShizukuHelper.hasPermission()
        val adbMode = when {
            !perm -> RootMode.NONE
            ShizukuHelper.uid() == 0 -> RootMode.SHIZUKU_ROOT
            else -> RootMode.SHIZUKU_SHELL
        }
        val prev = UiState.mode

        val candidates = when (UiState.profile) {
            MethodProfile.ADB_GKI -> listOf(RootMode.SHIZUKU_ROOT, RootMode.ADB_SU, RootMode.SHIZUKU_SHELL)
            MethodProfile.ROOT_ADB -> listOf(RootMode.SU, RootMode.SHIZUKU_ROOT, RootMode.SHIZUKU_SHELL)
            MethodProfile.ALL -> listOf(
                RootMode.SU, RootMode.SHIZUKU_ROOT, RootMode.ADB_SU, RootMode.SHIZUKU_SHELL
            )
        }

        var result = RootMode.NONE
        for (c in candidates) {
            val ok = when (c) {
                RootMode.SU -> if (probe) probeDirectSu() else prev == RootMode.SU
                RootMode.ADB_SU -> perm && (if (probe) probeAdbSu() else prev == RootMode.ADB_SU)
                RootMode.SHIZUKU_ROOT -> adbMode == RootMode.SHIZUKU_ROOT
                RootMode.SHIZUKU_SHELL -> adbMode == RootMode.SHIZUKU_SHELL
                RootMode.NONE -> false
            }
            if (ok) {
                result = c
                break
            }
        }

        UiState.shizukuRunning = running
        UiState.mode = result
    }

    /** ขอ su ตรงจากแอป */
    private fun probeDirectSu(): Boolean {
        for (bin in suCandidates) {
            try {
                val p = ProcessBuilder(bin, "-c", "id").redirectErrorStream(true).start()
                val r = collect(p, 15_000)
                if (r.output.contains("uid=0")) {
                    suBinary = bin
                    return true
                }
            } catch (e: Throwable) {
                // ไม่มีไฟล์นี้ ลองตัวถัดไป
            }
        }
        suBinary = null
        return false
    }

    /** ยกเป็น root จาก ADB shell (Shizuku) ด้วย su */
    private fun probeAdbSu(): Boolean = try {
        ShizukuHelper.exec("su -c id").output.contains("uid=0")
    } catch (e: Throwable) {
        false
    }

    /** รันคำสั่งตามช่องทางปัจจุบัน (เรียกใน background thread) */
    fun exec(command: String): ExecResult = try {
        when (UiState.mode) {
            RootMode.SU -> suExec(command)
            RootMode.ADB_SU -> ShizukuHelper.exec("su -c " + shQuote(command))
            RootMode.SHIZUKU_ROOT, RootMode.SHIZUKU_SHELL -> ShizukuHelper.exec(command)
            RootMode.NONE -> ExecResult("ยังไม่มีสิทธิ์ (ลองกด Use Root หรือเปลี่ยนรูปแบบใน ตั้งค่า)", -1)
        }
    } catch (e: Throwable) {
        ExecResult("ข้อผิดพลาด: ${e.message ?: e.javaClass.simpleName}", -1)
    }

    private fun suExec(command: String): ExecResult = try {
        val p = ProcessBuilder(suBinary ?: "su", "-c", command).redirectErrorStream(true).start()
        collect(p)
    } catch (e: Throwable) {
        ExecResult("เรียก su ไม่ได้: ${e.message}", -1)
    }

    private fun shQuote(s: String): String = "'" + s.replace("'", "'\\''") + "'"

    /** อ่านผลลัพธ์ + กันค้าง (ตัดทิ้งเมื่อเกินเวลา) ไม่ใช้ Process.waitFor(timeout) เพราะ Shizuku process ไม่รองรับ */
    internal fun collect(p: Process, timeoutMs: Long = 60_000): ExecResult {
        val done = AtomicBoolean(false)
        val watchdog = Thread {
            try {
                var waited = 0L
                while (!done.get() && waited < timeoutMs) {
                    Thread.sleep(200)
                    waited += 200
                }
                if (!done.get()) p.destroy()
            } catch (e: Throwable) {
            }
        }
        watchdog.isDaemon = true
        watchdog.start()

        val out = try {
            p.inputStream.bufferedReader().readText()
        } finally {
            done.set(true)
        }
        val code = try {
            p.waitFor()
        } catch (e: Throwable) {
            -1
        }
        return ExecResult(out.trimEnd().ifBlank { "(ไม่มีผลลัพธ์)" }, code)
    }
}
