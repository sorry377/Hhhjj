package com.example.appmanager

import java.util.concurrent.TimeUnit

data class ExecResult(val output: String, val exitCode: Int)

object RootManager {

    /**
     * ตรวจสอบสิทธิ์ที่มี
     * trySu = true จะลองเรียก su จริง (Magisk/KernelSU อาจเด้งให้กดอนุญาต) ต้องเรียกใน background thread
     * trySu = false ตรวจเฉพาะ Shizuku (เบา เรียกตอนเปิดแอปได้)
     */
    fun refresh(trySu: Boolean) {
        UiState.shizukuRunning = ShizukuHelper.isServiceRunning()

        val shizukuMode = when {
            !ShizukuHelper.hasPermission() -> RootMode.NONE
            ShizukuHelper.uid() == 0 -> RootMode.SHIZUKU_ROOT
            else -> RootMode.SHIZUKU_SHELL
        }

        UiState.mode = when {
            trySu && suWorks() -> RootMode.SU
            !trySu && UiState.mode == RootMode.SU -> RootMode.SU
            else -> shizukuMode
        }
    }

    private fun suWorks(): Boolean = try {
        val p = ProcessBuilder("su", "-c", "id").redirectErrorStream(true).start()
        if (!p.waitFor(20, TimeUnit.SECONDS)) {
            p.destroy()
            false
        } else {
            p.inputStream.bufferedReader().readText().contains("uid=0")
        }
    } catch (e: Exception) {
        false
    }

    /** รันคำสั่งตามโหมดปัจจุบัน (เรียกใน background thread) */
    fun exec(command: String): ExecResult = when (UiState.mode) {
        RootMode.SU -> suExec(command)
        RootMode.SHIZUKU_ROOT, RootMode.SHIZUKU_SHELL -> ShizukuHelper.exec(command)
        RootMode.NONE -> ExecResult("ยังไม่มีสิทธิ์ (ต้องใช้ su หรือ Shizuku)", -1)
    }

    private fun suExec(command: String): ExecResult = try {
        val p = ProcessBuilder("su", "-c", command).redirectErrorStream(true).start()
        collect(p)
    } catch (e: Exception) {
        ExecResult("เรียก su ไม่ได้: ${e.message}", -1)
    }

    /** อ่านผลลัพธ์ + กันค้าง (ตัดทิ้งหลัง 60 วินาที) */
    internal fun collect(p: Process): ExecResult {
        val watchdog = Thread {
            try {
                if (!p.waitFor(60, TimeUnit.SECONDS)) p.destroy()
            } catch (_: InterruptedException) {
            }
        }
        watchdog.isDaemon = true
        watchdog.start()
        val out = p.inputStream.bufferedReader().readText()
        val code = try { p.waitFor() } catch (e: Exception) { -1 }
        watchdog.interrupt()
        return ExecResult(out.trimEnd().ifBlank { "(ไม่มีผลลัพธ์)" }, code)
    }
}
