package com.example.appmanager

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap

data class AppItem(
    val name: String,
    val packageName: String,
    val icon: ImageBitmap?
)

enum class RootMode { NONE, SU, SHIZUKU_ROOT, SHIZUKU_SHELL }

enum class Screen { LIST, DETAIL, TERMINAL }

object UiState {
    var mode by mutableStateOf(RootMode.NONE)
    var shizukuRunning by mutableStateOf(false)
    var checking by mutableStateOf(false)

    var apps by mutableStateOf<List<AppItem>>(emptyList())
    var selected by mutableStateOf<AppItem?>(null)
    var screen by mutableStateOf(Screen.LIST)
    var query by mutableStateOf("")
    var log by mutableStateOf("")

    val granted: Boolean get() = mode != RootMode.NONE
    val isRealRoot: Boolean get() = mode == RootMode.SU || mode == RootMode.SHIZUKU_ROOT

    fun appendLog(text: String) {
        val t = log + text + "\n"
        log = if (t.length > 20000) t.takeLast(20000) else t
    }
}
