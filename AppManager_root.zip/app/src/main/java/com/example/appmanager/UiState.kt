package com.example.appmanager

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap

data class AppItem(
    val name: String,
    val packageName: String,
    val icon: ImageBitmap?
)

/** ช่องทางที่ใช้รันคำสั่งอยู่ตอนนี้ */
enum class RootMode { NONE, SU, ADB_SU, SHIZUKU_ROOT, SHIZUKU_SHELL }

/** รูปแบบการขอสิทธิ์ที่ผู้ใช้เลือกใน Settings */
enum class MethodProfile { ADB_GKI, ROOT_ADB, ALL }

enum class Screen { LIST, DETAIL, TERMINAL, SETTINGS }

object UiState {
    var mode by mutableStateOf(RootMode.NONE)
    var profile by mutableStateOf(MethodProfile.ALL)
    var shizukuRunning by mutableStateOf(false)
    var checking by mutableStateOf(false)
    var gateNote by mutableStateOf("")
    var crashReport by mutableStateOf<String?>(null)

    var apps by mutableStateOf<List<AppItem>>(emptyList())
    var selected by mutableStateOf<AppItem?>(null)
    var screen by mutableStateOf(Screen.LIST)
    var query by mutableStateOf("")
    var log by mutableStateOf("")

    val granted: Boolean get() = mode != RootMode.NONE
    val isRealRoot: Boolean
        get() = mode == RootMode.SU || mode == RootMode.ADB_SU || mode == RootMode.SHIZUKU_ROOT

    fun appendLog(text: String) {
        val t = log + text + "\n"
        log = if (t.length > 20000) t.takeLast(20000) else t
    }
}
