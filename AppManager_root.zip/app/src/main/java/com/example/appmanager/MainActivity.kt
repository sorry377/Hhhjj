package com.example.appmanager

import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.File

class MainActivity : ComponentActivity() {

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { _, _ ->
        safeRefresh()
    }

    private val binderListener = Shizuku.OnBinderReceivedListener {
        safeRefresh()
    }

    private fun safeRefresh() {
        try {
            RootManager.refresh(false)
        } catch (e: Throwable) {
        }
    }

    /** เก็บ stacktrace ลงไฟล์ ถ้าแอปปิดตัว เปิดครั้งหน้าจะแสดงให้คัดลอกส่งมาได้ */
    private fun installCrashLogger() {
        val file = File(filesDir, "crash.txt")
        if (file.exists()) {
            UiState.crashReport = try {
                file.readText()
            } catch (e: Throwable) {
                null
            }
            file.delete()
        }
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                file.writeText(Log.getStackTraceString(e))
            } catch (x: Throwable) {
            }
            old?.uncaughtException(t, e)
        }
    }

    private fun loadSettings() {
        val saved = getSharedPreferences("settings", MODE_PRIVATE).getString("profile", null)
        UiState.profile = MethodProfile.values().firstOrNull { it.name == saved } ?: MethodProfile.ALL
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        installCrashLogger()
        loadSettings()
        Shizuku.addRequestPermissionResultListener(permissionListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        safeRefresh()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                AppScreen()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        safeRefresh()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        super.onDestroy()
    }
}

// ---------- helpers ----------

const val DETECT_CMD =
    "echo kernel: \$(uname -r); id; " +
        "for p in magisk ksu ap; do [ -e /data/adb/\$p ] && echo found: /data/adb/\$p; done; " +
        "[ -e /data/adb/ksud ] && echo found: ksud; true"

const val START_SHIZUKU_CMD =
    "sh /storage/emulated/0/Android/data/moe.shizuku.privileged.api/start.sh"

fun modeLabel(mode: RootMode): String = when (mode) {
    RootMode.SU -> "Root จริง (su โดยตรง)"
    RootMode.ADB_SU -> "Root จริง (ADB → su)"
    RootMode.SHIZUKU_ROOT -> "Root จริง (Shizuku รันด้วย root)"
    RootMode.SHIZUKU_SHELL -> "ADB ผ่าน Shizuku (ไม่ใช่ root)"
    RootMode.NONE -> "ยังไม่มีสิทธิ์"
}

fun profileTitle(p: MethodProfile): String = when (p) {
    MethodProfile.ADB_GKI -> "ADB + GKI"
    MethodProfile.ROOT_ADB -> "ROOT + ADB"
    MethodProfile.ALL -> "ทุกวิธี"
}

fun profileDesc(p: MethodProfile): String = when (p) {
    MethodProfile.ADB_GKI ->
        "ใช้ ADB (Shizuku) แล้วลองยกเป็น root จาก ADB shell ด้วย su ของ GKI root (KernelSU/APatch) หรือ Magisk ที่อนุญาตให้ shell ไม่เรียก su จากแอปตรง ๆ"
    MethodProfile.ROOT_ADB ->
        "ขอ su จากแอปโดยตรงก่อน (Magisk/KernelSU/APatch) ถ้าไม่ได้ใช้ ADB (Shizuku) แทน"
    MethodProfile.ALL ->
        "ลองตามลำดับ: su โดยตรง → Shizuku root → ADB ยกเป็น root (su) → ADB ปกติ"
}

fun rootHint(p: MethodProfile): String = when (p) {
    MethodProfile.ADB_GKI ->
        "ADB ยังยกเป็น root ไม่ได้ ถ้าเป็น GKI root (KernelSU/APatch) ให้เปิดสิทธิ์ Superuser ให้ shell (ADB) ในแอปจัดการ root แล้วกด Use Root ใหม่"
    MethodProfile.ROOT_ADB ->
        "su ไม่ตอบรับ ให้สิทธิ์ App Manager ในรายการ Superuser ของ Magisk/KernelSU/APatch แล้วกด Use Root ใหม่"
    MethodProfile.ALL ->
        "ทุกวิธียังไม่ได้ root ให้สิทธิ์ App Manager หรือ shell (ADB) ในแอปจัดการ root แล้วกด Use Root ใหม่ ถ้าเครื่องไม่ได้ root จะได้แค่ระดับ ADB"
}

fun saveProfile(context: Context, p: MethodProfile) {
    UiState.profile = p
    context.getSharedPreferences("settings", Context.MODE_PRIVATE)
        .edit().putString("profile", p.name).apply()
    try {
        RootManager.refresh(false)
    } catch (e: Throwable) {
    }
}

fun goBack() {
    UiState.screen = Screen.LIST
    UiState.selected = null
}

fun runShell(scope: CoroutineScope, command: String) {
    scope.launch {
        UiState.appendLog("$ $command")
        try {
            val r = withContext(Dispatchers.IO) { RootManager.exec(command) }
            UiState.appendLog(r.output + "\n[exit ${r.exitCode}]")
        } catch (e: Throwable) {
            if (e is CancellationException) throw e
            UiState.appendLog("ข้อผิดพลาด: ${e.message ?: e.javaClass.simpleName}")
        }
    }
}

fun useRoot(scope: CoroutineScope) {
    scope.launch {
        UiState.checking = true
        try {
            UiState.appendLog("== ตรวจสอบสิทธิ์ (${profileTitle(UiState.profile)}) ==")
            val r = withContext(Dispatchers.IO) {
                RootManager.refresh(true)
                RootManager.exec("id")
            }
            UiState.appendLog("ช่องทาง: ${modeLabel(UiState.mode)}")
            UiState.appendLog(r.output)
            if (!UiState.isRealRoot) UiState.appendLog(rootHint(UiState.profile))
        } catch (e: Throwable) {
            if (e is CancellationException) throw e
            UiState.appendLog("ข้อผิดพลาด: ${e.message ?: e.javaClass.simpleName}")
        } finally {
            UiState.checking = false
        }
    }
}

// ---------- screens ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppScreen() {
    val context = LocalContext.current
    val sel = UiState.selected

    LaunchedEffect(UiState.granted) {
        if (UiState.granted && UiState.apps.isEmpty()) {
            UiState.apps = withContext(Dispatchers.IO) { loadInstalledApps(context) }
        }
    }

    BackHandler(enabled = UiState.screen != Screen.LIST) { goBack() }

    val title = when (UiState.screen) {
        Screen.LIST -> "App Manager"
        Screen.DETAIL -> sel?.name ?: "App Manager"
        Screen.TERMINAL -> "Terminal"
        Screen.SETTINGS -> "ตั้งค่า"
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    if (UiState.screen != Screen.LIST) {
                        IconButton(onClick = { goBack() }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "กลับ")
                        }
                    }
                },
                actions = {
                    if (UiState.granted && UiState.screen == Screen.LIST) {
                        TextButton(onClick = { UiState.screen = Screen.TERMINAL }) { Text("Terminal") }
                        TextButton(onClick = { UiState.screen = Screen.SETTINGS }) { Text("ตั้งค่า") }
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            when {
                UiState.screen == Screen.TERMINAL -> TerminalScreen()
                UiState.screen == Screen.SETTINGS -> SettingsScreen()
                UiState.screen == Screen.DETAIL && sel != null -> AppDetail(sel)
                !UiState.granted -> AccessGate()
                else -> AppList()
            }
        }
    }

    UiState.crashReport?.let { CrashDialog(it) }
}

@Composable
fun CrashDialog(report: String) {
    val clipboard = LocalClipboardManager.current
    AlertDialog(
        onDismissRequest = { UiState.crashReport = null },
        title = { Text("แอปเคยปิดตัวจากข้อผิดพลาด") },
        text = {
            Column(Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState())) {
                SelectionContainer {
                    Text(
                        report.take(4000),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { clipboard.setText(AnnotatedString(report)) }) { Text("คัดลอก") }
        },
        dismissButton = {
            TextButton(onClick = { UiState.crashReport = null }) { Text("ปิด") }
        }
    )
}

@Composable
fun ModeBadge() {
    val color = when (UiState.mode) {
        RootMode.SU, RootMode.ADB_SU, RootMode.SHIZUKU_ROOT -> Color(0xFF4CAF50)
        RootMode.SHIZUKU_SHELL -> Color(0xFFFFB300)
        RootMode.NONE -> Color(0xFFEF5350)
    }
    Text(
        "สถานะ: ${modeLabel(UiState.mode)}  |  รูปแบบ: ${profileTitle(UiState.profile)}",
        color = color,
        style = MaterialTheme.typography.labelLarge
    )
}

@Composable
fun ProfilePicker() {
    val context = LocalContext.current
    Column {
        MethodProfile.values().forEach { p ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { saveProfile(context, p) }
                    .padding(vertical = 6.dp),
                verticalAlignment = Alignment.Top
            ) {
                RadioButton(selected = UiState.profile == p, onClick = { saveProfile(context, p) })
                Column(Modifier.padding(start = 4.dp, top = 12.dp)) {
                    Text(profileTitle(p), style = MaterialTheme.typography.titleSmall)
                    Text(
                        profileDesc(p),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun AccessGate() {
    val scope = rememberCoroutineScope()
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("ต้องมีสิทธิ์ก่อนใช้งาน", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Text(
            "Shizuku: ${if (UiState.shizukuRunning) "ทำงานอยู่" else "ยังไม่ทำงาน"}",
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(Modifier.height(12.dp))

        ProfilePicker()

        Spacer(Modifier.height(12.dp))

        Button(
            onClick = { ShizukuHelper.requestPermission() },
            enabled = UiState.shizukuRunning,
            modifier = Modifier.fillMaxWidth()
        ) { Text("ขอสิทธิ์ Shizuku (ADB)") }

        Spacer(Modifier.height(8.dp))

        Button(
            onClick = {
                scope.launch {
                    UiState.checking = true
                    try {
                        withContext(Dispatchers.IO) { RootManager.refresh(true) }
                        UiState.gateNote = if (UiState.granted) "" else rootHint(UiState.profile)
                    } catch (e: Throwable) {
                        if (e is CancellationException) throw e
                        UiState.gateNote = "ข้อผิดพลาด: ${e.message ?: e.javaClass.simpleName}"
                    } finally {
                        UiState.checking = false
                    }
                }
            },
            enabled = !UiState.checking,
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (UiState.checking) "กำลังตรวจสอบ..." else "ตรวจสอบสิทธิ์ตามรูปแบบที่เลือก") }

        Spacer(Modifier.height(8.dp))

        OutlinedButton(
            onClick = {
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) { RootManager.refresh(false) }
                    } catch (e: Throwable) {
                        if (e is CancellationException) throw e
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("ตรวจสอบ Shizuku อีกครั้ง") }

        if (UiState.gateNote.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text(UiState.gateNote, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun SettingsScreen() {
    val scope = rememberCoroutineScope()
    val kernel = System.getProperty("os.version") ?: "ไม่ทราบ"
    val gki = Regex("-android\\d+-").containsMatchIn(kernel)

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        ModeBadge()
        Spacer(Modifier.height(12.dp))
        Text("รูปแบบการขอสิทธิ์", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(4.dp))
        ProfilePicker()

        Spacer(Modifier.height(12.dp))
        Text("Kernel: $kernel", style = MaterialTheme.typography.bodySmall)
        Text(
            "GKI: ${if (gki) "ใช่ (ดูจากชื่อ kernel)" else "ไม่ใช่ / ไม่ทราบ"}",
            style = MaterialTheme.typography.bodySmall
        )

        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { useRoot(scope) },
            enabled = !UiState.checking,
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (UiState.checking) "กำลังตรวจสอบ..." else "ตรวจสอบสิทธิ์ตอนนี้ (Use Root)") }

        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            onClick = { runShell(scope, DETECT_CMD) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("ตรวจสอบระบบ root (Magisk/KernelSU/APatch)") }

        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            onClick = { runShell(scope, START_SHIZUKU_CMD) },
            enabled = UiState.isRealRoot,
            modifier = Modifier.fillMaxWidth()
        ) { Text("เริ่ม Shizuku ด้วย root") }

        Spacer(Modifier.height(12.dp))
        Text(
            "GKI root (KernelSU/APatch) มักไม่มีหน้าต่างถามสิทธิ์เหมือน Magisk " +
                "ต้องเปิดสิทธิ์ Superuser ให้ App Manager หรือให้ shell (ADB) ในแอปจัดการ root เอง แล้วกดตรวจสอบอีกครั้ง",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(16.dp))
        LogBox()
    }
}

@Composable
fun AppList() {
    val q = UiState.query.trim()
    val filtered = remember(UiState.apps, q) {
        if (q.isEmpty()) UiState.apps
        else UiState.apps.filter {
            it.name.contains(q, ignoreCase = true) || it.packageName.contains(q, ignoreCase = true)
        }
    }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            ModeBadge()
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = UiState.query,
                onValueChange = { UiState.query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("ค้นหาชื่อแอป หรือ package") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                trailingIcon = {
                    if (UiState.query.isNotEmpty()) {
                        IconButton(onClick = { UiState.query = "" }) {
                            Icon(Icons.Filled.Clear, contentDescription = "ล้าง")
                        }
                    }
                }
            )
        }

        if (filtered.isEmpty()) {
            Text(
                if (UiState.apps.isEmpty()) "กำลังโหลดรายการแอป..." else "ไม่พบแอปที่ค้นหา",
                modifier = Modifier.padding(16.dp),
                style = MaterialTheme.typography.bodyMedium
            )
        }

        LazyColumn(Modifier.fillMaxSize()) {
            items(filtered, key = { it.packageName }) { app ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable {
                            UiState.selected = app
                            UiState.screen = Screen.DETAIL
                        }
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    app.icon?.let {
                        Image(
                            bitmap = it,
                            contentDescription = null,
                            modifier = Modifier.size(44.dp)
                        )
                    } ?: Spacer(Modifier.size(44.dp))
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text(app.name, style = MaterialTheme.typography.titleMedium)
                        Text(
                            app.packageName,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AppDetail(app: AppItem) {
    val scope = rememberCoroutineScope()
    var confirmClear by remember { mutableStateOf(false) }
    val pkg = app.packageName

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            app.icon?.let {
                Image(bitmap = it, contentDescription = null, modifier = Modifier.size(72.dp))
            }
            Spacer(Modifier.width(16.dp))
            Column {
                Text(app.name, style = MaterialTheme.typography.headlineSmall)
                Text(pkg, style = MaterialTheme.typography.bodyMedium)
            }
        }

        Spacer(Modifier.height(12.dp))
        ModeBadge()
        Spacer(Modifier.height(12.dp))

        Button(
            onClick = { useRoot(scope) },
            enabled = !UiState.checking,
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (UiState.checking) "กำลังตรวจสอบ..." else "Use Root") }

        Spacer(Modifier.height(12.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = { runShell(scope, "monkey -p $pkg -c android.intent.category.LAUNCHER 1") },
                modifier = Modifier.weight(1f)
            ) { Text("เปิดแอป") }
            OutlinedButton(
                onClick = { runShell(scope, "am force-stop $pkg") },
                modifier = Modifier.weight(1f)
            ) { Text("Force stop") }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = { runShell(scope, "pm disable-user --user 0 $pkg") },
                modifier = Modifier.weight(1f)
            ) { Text("ปิดใช้งาน") }
            OutlinedButton(
                onClick = { runShell(scope, "pm enable $pkg") },
                modifier = Modifier.weight(1f)
            ) { Text("เปิดใช้งาน") }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = {
                    runShell(
                        scope,
                        "dumpsys package $pkg | grep -E 'versionName|versionCode|userId|dataDir|codePath'"
                    )
                },
                modifier = Modifier.weight(1f)
            ) { Text("ข้อมูลแอป") }
            OutlinedButton(
                onClick = { confirmClear = true },
                modifier = Modifier.weight(1f)
            ) { Text("ล้างข้อมูล") }
        }

        Spacer(Modifier.height(16.dp))
        Console(pkg)
        Spacer(Modifier.height(16.dp))
        LogBox()
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("ล้างข้อมูลแอป?") },
            text = { Text("ข้อมูลทั้งหมดของ ${app.name} จะถูกลบและกู้คืนไม่ได้") },
            confirmButton = {
                TextButton(onClick = {
                    confirmClear = false
                    runShell(scope, "pm clear $pkg")
                }) { Text("ล้างข้อมูล") }
            },
            dismissButton = {
                TextButton(onClick = { confirmClear = false }) { Text("ยกเลิก") }
            }
        )
    }
}

@Composable
fun TerminalScreen() {
    val scope = rememberCoroutineScope()
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        ModeBadge()
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { useRoot(scope) },
            enabled = !UiState.checking,
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (UiState.checking) "กำลังตรวจสอบ..." else "Use Root") }
        Spacer(Modifier.height(16.dp))
        Console(null)
        Spacer(Modifier.height(16.dp))
        LogBox()
    }
}

@Composable
fun Console(pkg: String?) {
    val scope = rememberCoroutineScope()
    var cmd by remember { mutableStateOf("") }

    OutlinedTextField(
        value = cmd,
        onValueChange = { cmd = it },
        modifier = Modifier.fillMaxWidth(),
        label = {
            Text(if (pkg != null) "รันโค้ด shell ({pkg} = $pkg)" else "รันโค้ด shell")
        },
        maxLines = 4
    )
    Spacer(Modifier.height(8.dp))
    Button(
        onClick = {
            if (cmd.isNotBlank()) runShell(scope, cmd.replace("{pkg}", pkg ?: ""))
        },
        modifier = Modifier.fillMaxWidth()
    ) { Text("รัน") }
}

@Composable
fun LogBox() {
    if (UiState.log.isEmpty()) return
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("ผลลัพธ์", style = MaterialTheme.typography.titleSmall)
                TextButton(onClick = { UiState.log = "" }) { Text("ล้าง") }
            }
            SelectionContainer {
                Text(
                    UiState.log,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp
                )
            }
        }
    }
}

fun loadInstalledApps(context: Context): List<AppItem> {
    val pm = context.packageManager
    return pm.getInstalledApplications(PackageManager.GET_META_DATA)
        .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
        .map { info ->
            AppItem(
                name = pm.getApplicationLabel(info).toString(),
                packageName = info.packageName,
                icon = try {
                    pm.getApplicationIcon(info).toBitmap(96, 96).asImageBitmap()
                } catch (e: Exception) {
                    null
                }
            )
        }
        .sortedBy { it.name.lowercase() }
}
