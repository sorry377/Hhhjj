package com.example.appmanager

import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { _, _ ->
        RootManager.refresh(false)
    }

    private val binderListener = Shizuku.OnBinderReceivedListener {
        RootManager.refresh(false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(permissionListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        RootManager.refresh(false)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                AppScreen()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        RootManager.refresh(false)
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        super.onDestroy()
    }
}

const val NO_ROOT_HINT =
    "เครื่องนี้ยังไม่ใช่ root จริง คำสั่งทำงานระดับ ADB (uid 2000)\n" +
        "ถ้าเครื่อง root แล้ว (Magisk/KernelSU) ให้กด Use Root แล้วอนุญาตสิทธิ์ su " +
        "หรือเปิด Shizuku แบบ root"

fun modeLabel(mode: RootMode): String = when (mode) {
    RootMode.SU -> "Root จริง (su)"
    RootMode.SHIZUKU_ROOT -> "Root จริง (Shizuku รันด้วย root)"
    RootMode.SHIZUKU_SHELL -> "Shizuku โหมด ADB (ไม่ใช่ root)"
    RootMode.NONE -> "ยังไม่มีสิทธิ์"
}

fun goBack() {
    UiState.screen = Screen.LIST
    UiState.selected = null
}

fun runShell(scope: CoroutineScope, command: String) {
    scope.launch {
        UiState.appendLog("$ $command")
        val r = withContext(Dispatchers.IO) { RootManager.exec(command) }
        UiState.appendLog(r.output + "\n[exit ${r.exitCode}]")
    }
}

fun useRoot(scope: CoroutineScope) {
    scope.launch {
        UiState.checking = true
        UiState.appendLog("== ตรวจสอบสิทธิ์ ==")
        val r = withContext(Dispatchers.IO) {
            RootManager.refresh(true)
            RootManager.exec("id")
        }
        UiState.checking = false
        UiState.appendLog("โหมด: ${modeLabel(UiState.mode)}")
        UiState.appendLog(r.output)
        if (!UiState.isRealRoot) UiState.appendLog(NO_ROOT_HINT)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppScreen() {
    val context = LocalContext.current
    val sel = UiState.selected

    LaunchedEffect(UiState.granted) {
        if (UiState.granted && UiState.apps.isEmpty()) {
            UiState.apps = withContext(Dispatchers.IO) { loadInstalledApps(context) }
        }
    }

    BackHandler(enabled = UiState.screen != Screen.LIST) { goBack() }

    val title = when (UiState.screen) {
        Screen.LIST -> "App Manager"
        Screen.DETAIL -> sel?.name ?: "App Manager"
        Screen.TERMINAL -> "Terminal"
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    if (UiState.screen != Screen.LIST) {
                        IconButton(onClick = { goBack() }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "กลับ")
                        }
                    }
                },
                actions = {
                    if (UiState.granted && UiState.screen == Screen.LIST) {
                        TextButton(onClick = { UiState.screen = Screen.TERMINAL }) {
                            Text("Terminal")
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            when {
                !UiState.granted -> AccessGate()
                UiState.screen == Screen.TERMINAL -> TerminalScreen()
                UiState.screen == Screen.DETAIL && sel != null -> AppDetail(sel)
                else -> AppList()
            }
        }
    }
}

@Composable
fun ModeBadge() {
    val color = when (UiState.mode) {
        RootMode.SU, RootMode.SHIZUKU_ROOT -> Color(0xFF4CAF50)
        RootMode.SHIZUKU_SHELL -> Color(0xFFFFB300)
        RootMode.NONE -> Color(0xFFEF5350)
    }
    Text(
        "สถานะ: ${modeLabel(UiState.mode)}",
        color = color,
        style = MaterialTheme.typography.labelLarge
    )
}

@Composable
fun AccessGate() {
    val scope = rememberCoroutineScope()
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("ต้องมีสิทธิ์ก่อนใช้งาน", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Text(
            "Shizuku: ${if (UiState.shizukuRunning) "ทำงานอยู่" else "ยังไม่ทำงาน"}",
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "เครื่อง root (Magisk/KernelSU): กด \"ตรวจสอบ Root (su)\" แล้วอนุญาต\n" +
                "เครื่องไม่ root: เปิด Shizuku แล้วขอสิทธิ์ (ได้ระดับ ADB ไม่ใช่ root จริง)",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(20.dp))

        Button(
            onClick = { ShizukuHelper.requestPermission() },
            enabled = UiState.shizukuRunning,
            modifier = Modifier.fillMaxWidth()
        ) { Text("ขอสิทธิ์ Shizuku") }

        Spacer(Modifier.height(8.dp))

        Button(
            onClick = {
                scope.launch {
                    UiState.checking = true
                    withContext(Dispatchers.IO) { RootManager.refresh(true) }
                    UiState.checking = false
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (UiState.checking) "กำลังตรวจสอบ..." else "ตรวจสอบ Root (su)") }

        Spacer(Modifier.height(8.dp))

        OutlinedButton(
            onClick = {
                scope.launch { withContext(Dispatchers.IO) { RootManager.refresh(false) } }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("ตรวจสอบ Shizuku อีกครั้ง") }
    }
}

@Composable
fun AppList() {
    val q = UiState.query.trim()
    val filtered = remember(UiState.apps, q) {
        if (q.isEmpty()) UiState.apps
        else UiState.apps.filter {
            it.name.contains(q, ignoreCase = true) || it.packageName.contains(q, ignoreCase = true)
        }
    }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            ModeBadge()
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = UiState.query,
                onValueChange = { UiState.query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("ค้นหาชื่อแอป หรือ package") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                trailingIcon = {
                    if (UiState.query.isNotEmpty()) {
                        IconButton(onClick = { UiState.query = "" }) {
                            Icon(Icons.Filled.Clear, contentDescription = "ล้าง")
                        }
                    }
                }
            )
        }

        if (filtered.isEmpty()) {
            Text(
                if (UiState.apps.isEmpty()) "กำลังโหลดรายการแอป..." else "ไม่พบแอปที่ค้นหา",
                modifier = Modifier.padding(16.dp),
                style = MaterialTheme.typography.bodyMedium
            )
        }

        LazyColumn(Modifier.fillMaxSize()) {
            items(filtered, key = { it.packageName }) { app ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable {
                            UiState.selected = app
                            UiState.screen = Screen.DETAIL
                        }
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    app.icon?.let {
                        Image(
                            bitmap = it,
                            contentDescription = null,
                            modifier = Modifier.size(44.dp)
                        )
                    } ?: Spacer(Modifier.size(44.dp))
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text(app.name, style = MaterialTheme.typography.titleMedium)
                        Text(
                            app.packageName,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AppDetail(app: AppItem) {
    val scope = rememberCoroutineScope()
    var confirmClear by remember { mutableStateOf(false) }
    val pkg = app.packageName

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            app.icon?.let {
                Image(bitmap = it, contentDescription = null, modifier = Modifier.size(72.dp))
            }
            Spacer(Modifier.width(16.dp))
            Column {
                Text(app.name, style = MaterialTheme.typography.headlineSmall)
                Text(pkg, style = MaterialTheme.typography.bodyMedium)
            }
        }

        Spacer(Modifier.height(12.dp))
        ModeBadge()
        Spacer(Modifier.height(12.dp))

        Button(
            onClick = { useRoot(scope) },
            enabled = !UiState.checking,
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (UiState.checking) "กำลังตรวจสอบ..." else "Use Root") }

        Spacer(Modifier.height(12.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = { runShell(scope, "monkey -p $pkg -c android.intent.category.LAUNCHER 1") },
                modifier = Modifier.weight(1f)
            ) { Text("เปิดแอป") }
            OutlinedButton(
                onClick = { runShell(scope, "am force-stop $pkg") },
                modifier = Modifier.weight(1f)
            ) { Text("Force stop") }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = { runShell(scope, "pm disable-user --user 0 $pkg") },
                modifier = Modifier.weight(1f)
            ) { Text("ปิดใช้งาน") }
            OutlinedButton(
                onClick = { runShell(scope, "pm enable $pkg") },
                modifier = Modifier.weight(1f)
            ) { Text("เปิดใช้งาน") }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = {
                    runShell(
                        scope,
                        "dumpsys package $pkg | grep -E 'versionName|versionCode|userId|dataDir|codePath'"
                    )
                },
                modifier = Modifier.weight(1f)
            ) { Text("ข้อมูลแอป") }
            OutlinedButton(
                onClick = { confirmClear = true },
                modifier = Modifier.weight(1f)
            ) { Text("ล้างข้อมูล") }
        }

        Spacer(Modifier.height(16.dp))
        Console(pkg)
        Spacer(Modifier.height(16.dp))
        LogBox()
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("ล้างข้อมูลแอป?") },
            text = { Text("ข้อมูลทั้งหมดของ ${app.name} จะถูกลบและกู้คืนไม่ได้") },
            confirmButton = {
                TextButton(onClick = {
                    confirmClear = false
                    runShell(scope, "pm clear $pkg")
                }) { Text("ล้างข้อมูล") }
            },
            dismissButton = {
                TextButton(onClick = { confirmClear = false }) { Text("ยกเลิก") }
            }
        )
    }
}

@Composable
fun TerminalScreen() {
    val scope = rememberCoroutineScope()
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        ModeBadge()
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { useRoot(scope) },
            enabled = !UiState.checking,
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (UiState.checking) "กำลังตรวจสอบ..." else "Use Root") }
        Spacer(Modifier.height(16.dp))
        Console(null)
        Spacer(Modifier.height(16.dp))
        LogBox()
    }
}

@Composable
fun Console(pkg: String?) {
    val scope = rememberCoroutineScope()
    var cmd by remember { mutableStateOf("") }

    OutlinedTextField(
        value = cmd,
        onValueChange = { cmd = it },
        modifier = Modifier.fillMaxWidth(),
        label = {
            Text(if (pkg != null) "รันโค้ด shell ({pkg} = $pkg)" else "รันโค้ด shell")
        },
        maxLines = 4
    )
    Spacer(Modifier.height(8.dp))
    Button(
        onClick = {
            if (cmd.isNotBlank()) runShell(scope, cmd.replace("{pkg}", pkg ?: ""))
        },
        modifier = Modifier.fillMaxWidth()
    ) { Text("รัน") }
}

@Composable
fun LogBox() {
    if (UiState.log.isEmpty()) return
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("ผลลัพธ์", style = MaterialTheme.typography.titleSmall)
                TextButton(onClick = { UiState.log = "" }) { Text("ล้าง") }
            }
            SelectionContainer {
                Text(
                    UiState.log,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp
                )
            }
        }
    }
}

fun loadInstalledApps(context: Context): List<AppItem> {
    val pm = context.packageManager
    return pm.getInstalledApplications(PackageManager.GET_META_DATA)
        .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
        .map { info ->
            AppItem(
                name = pm.getApplicationLabel(info).toString(),
                packageName = info.packageName,
                icon = try {
                    pm.getApplicationIcon(info).toBitmap(96, 96).asImageBitmap()
                } catch (e: Exception) {
                    null
                }
            )
        }
        .sortedBy { it.name.lowercase() }
}
